
import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { collection, addDoc, onSnapshot } from 'firebase/firestore';

const ChatRooms = () => {
  const [rooms, setRooms] = useState([]);
  const [newRoom, setNewRoom] = useState('');

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'chatRooms'), (snapshot) => {
      const rooms = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setRooms(rooms);
    });

    return () => unsubscribe();
  }, []);

  const handleCreateRoom = async (e) => {
    e.preventDefault();
    if (newRoom.trim()) {
      await addDoc(collection(db, 'chatRooms'), { name: newRoom });
      setNewRoom('');
    }
  };

  return (
    <div>
      <form onSubmit={handleCreateRoom}>
        <input value={newRoom} onChange={(e) => setNewRoom(e.target.value)} placeholder="New Room Name" />
        <button type="submit">Create Room</button>
      </form>
      <div>
        {rooms.map(room => (
          <div key={room.id}>
            <p>{room.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ChatRooms;
