
import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore';
import { signOut } from 'firebase/auth';

const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'messages'), orderBy('timestamp'));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const messages = [];
      querySnapshot.forEach((doc) => {
        messages.push({ ...doc.data(), id: doc.id });
      });
      setMessages(messages);
    });

    return () => unsubscribe();
  }, []);

  const handleSend = async (e) => {
    e.preventDefault();
    if (newMessage.trim()) {
      await addDoc(collection(db, 'messages'), {
        text: newMessage,
        timestamp: new Date(),
        uid: auth.currentUser.uid,
        displayName: auth.currentUser.displayName,
      });
      setNewMessage('');
    }
  };

  return (
    <div>
      <div>
        {messages.map((message) => (
          <div key={message.id}>
            <p>{message.displayName}: {message.text}</p>
          </div>
        ))}
      </div>
      <form onSubmit={handleSend}>
        <input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type a message" />
        <button type="submit">Send</button>
      </form>
      <button onClick={() => signOut(auth)}>Logout</button>
    </div>
  );
};

export default Chat;
