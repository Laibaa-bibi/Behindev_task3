
import React, { useState } from 'react';
import { auth, storage } from '../firebase';
import { updateProfile } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const Profile = () => {
  const [displayName, setDisplayName] = useState(auth.currentUser.displayName || '');
  const [profilePicture, setProfilePicture] = useState(null);

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    if (profilePicture) {
      const storageRef = ref(storage, `profilePictures/${auth.currentUser.uid}`);
      await uploadBytes(storageRef, profilePicture);
      const photoURL = await getDownloadURL(storageRef);
      await updateProfile(auth.currentUser, { displayName, photoURL });
    } else {
      await updateProfile(auth.currentUser, { displayName });
    }
    
  };

  return (
    <form onSubmit={handleUpdateProfile}>
      <input type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Display Name" />
      <input type="file" onChange={(e) => setProfilePicture(e.target.files[0])} />
      <button type="submit">Update Profile</button>
    </form>
  );
};

export default Profile;
